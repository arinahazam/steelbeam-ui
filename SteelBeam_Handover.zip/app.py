import os
import sqlite3
import csv
from datetime import datetime
from io import StringIO, BytesIO
from flask import Flask, render_template, request, redirect, url_for, session, send_file, jsonify
from ultralytics import YOLO
from db import init_db
from utils import save_uploaded_files, run_model_yolo
from fpdf import FPDF
from flask import make_response

import csv
import io
from flask import make_response, request

app = Flask(__name__)
app.secret_key = "industrial_steel_secret" 

model = YOLO("models/yolo_beam.pt")
model.to("cpu")

@app.route("/")
def index(): 
    return render_template("index.html")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        session["user_id"] = request.form.get("username")
        return redirect(url_for("dashboard"))
    return render_template("signup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        session["user_id"] = request.form.get("username")
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if "user_id" not in session: return redirect(url_for('index'))
    return render_template("dashboard.html")

@app.route("/upload", methods=["GET", "POST"])
def upload_page(): 
    if "user_id" not in session: return redirect(url_for('index'))
    return render_template("upload.html")

@app.route("/process_upload", methods=["POST"])
def process_upload():
    if "user_id" not in session: return redirect(url_for('index'))
    
    files = request.files.getlist("media")
    if not files or files[0].filename == "": 
        return redirect(url_for("upload_page"))

    session_results = []
    conn = sqlite3.connect("steelbeam.db")
    cur = conn.cursor()

    for file in files:
        # EXACT logic from your working Code 2
        saved = save_uploaded_files([file])
        fname, fpath = saved[0]
        res = run_model_yolo(model, fpath)
        
        # INSERT AS PENDING - using the paths 'run_model_yolo' gave us
        primary_file = res["processed_files"][0]
        cur.execute("""
            INSERT INTO history (filename, processed_file, ibeam, tbeam, total, status, employee_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (fname, primary_file, res["counts"]["ibeam"], res["counts"]["tbeam"], 
              res["counts"]["total"], "PENDING", session.get("user_id", "Unknown"), 
              datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        
        session_results.append({
            "history_id": cur.lastrowid, # Needed for the Approve/Reject buttons
            "filename": fname,
            "processed_files": res["processed_files"],
            "counts": res["counts"],
            "is_video": res["is_video"]
        })

    conn.commit()
    conn.close()
    return render_template("verify.html", results=session_results)

@app.route("/verify_decision", methods=["POST"])
def verify_decision():
    h_id = request.form.get("history_id")
    # CHANGE: Get 'status' instead of 'decision'
    status_received = request.form.get("status") 
    
    # Check for the actual string sent by JS: 'APPROVED' or 'REJECTED'
    if status_received == "APPROVED":
        final_status = "APPROVED"
    else:
        final_status = "REJECTED"
    
    conn = sqlite3.connect("steelbeam.db")
    cur = conn.cursor()
    cur.execute("UPDATE history SET status = ? WHERE id = ?", (final_status, h_id))
    conn.commit()
    conn.close()
    return jsonify({"status": "success"})

@app.route("/history")
def history():
    if "user_id" not in session: return redirect(url_for('index'))
    conn = sqlite3.connect("steelbeam.db")
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    # Updated query to exclude PENDING status
    cur.execute("SELECT * FROM history WHERE status != 'PENDING' ORDER BY created_at DESC")
    entries = cur.fetchall()
    conn.close()
    return render_template("history.html", entries=entries)

@app.route("/report")
def report():
    if "user_id" not in session: return redirect(url_for('index'))
    conn = sqlite3.connect("steelbeam.db")
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    # Fetch only finalized records for the report
    cur.execute("SELECT * FROM history WHERE status != 'PENDING' ORDER BY created_at DESC")
    entries = cur.fetchall()
    
    # Calculate totals for the Metric Cards
    stats = {
        "total_beams": sum(row['total'] for row in entries),
        "approved": sum(1 for row in entries if row['status'] == 'APPROVED'),
        "rejected": sum(1 for row in entries if row['status'] == 'REJECTED')
    }
    
    conn.close()
    return render_template("report.html", entries=entries, stats=stats)



@app.route('/export_report')
def export_report():
    # Get the IDs from the URL query string (e.g., ?ids=1,2,15)
    ids_raw = request.args.get('ids', '')
    if not ids_raw:
        return "No records selected", 400
        
    id_list = ids_raw.split(',')

    conn = sqlite3.connect("steelbeam.db")
    cur = conn.cursor()
    
    # Fetch only the selected records
    query = f"SELECT employee_id, status, created_at, filename, ibeam, tbeam, total FROM history WHERE id IN ({','.join(['?']*len(id_list))})"
    cur.execute(query, id_list)
    rows = cur.fetchall()
    conn.close()

    # Generate CSV in memory
    si = io.StringIO()
    cw = csv.writer(si)
    
    # Add Header Row
    cw.writerow(['Verified By', 'Status', 'Date', 'Filename', 'I-Beam', 'T-Beam', 'Total'])
    
    # Add Data Rows
    cw.writerows(rows)

    # Create the response
    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename=production_report.csv"
    output.headers["Content-type"] = "text/csv"
    return output



@app.route('/export_pdf')
def export_pdf():
    if "user_id" not in session: return redirect(url_for('index'))
    
    # 1. Get IDs from URL
    ids_raw = request.args.get('ids', '')
    if not ids_raw:
        return "No records selected", 400
    id_list = ids_raw.split(',')

    # 2. Fetch Data
    conn = sqlite3.connect("steelbeam.db")
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    placeholders = ','.join(['?'] * len(id_list))
    query = f"SELECT employee_id, status, created_at, filename, ibeam, tbeam, total FROM history WHERE id IN ({placeholders})"
    cur.execute(query, id_list)
    rows = cur.fetchall()
    conn.close()

    # 3. Setup PDF (using Helvetica to avoid Arial warnings)
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("helvetica", "B", 16)
    pdf.cell(0, 10, "SteelBeam AI - Production Report", ln=True, align="C")
    pdf.set_font("helvetica", "", 10)
    pdf.cell(0, 10, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", ln=True, align="C")
    pdf.ln(10)

    # 4. Table Header
    pdf.set_fill_color(0, 45, 98) 
    pdf.set_text_color(255, 255, 255)
    pdf.set_font("helvetica", "B", 10)
    
    headers = ["Date", "File", "I-Beam", "T-Beam", "Total", "Status"]
    widths = [35, 55, 25, 25, 20, 30]
    
    for i in range(len(headers)):
        pdf.cell(widths[i], 10, headers[i], border=1, align="C", fill=True)
    pdf.ln()

    # 5. Table Body
    pdf.set_text_color(0, 0, 0)
    pdf.set_font("helvetica", "", 9)
    
    for row in rows:
        pdf.cell(widths[0], 10, str(row['created_at'])[:10], border=1)
        pdf.cell(widths[1], 10, str(row['filename'])[:22], border=1) 
        pdf.cell(widths[2], 10, str(row['ibeam']), border=1, align="C")
        pdf.cell(widths[3], 10, str(row['tbeam']), border=1, align="C")
        pdf.cell(widths[4], 10, str(row['total']), border=1, align="C")
        pdf.cell(widths[5], 10, str(row['status']), border=1, align="C")
        pdf.ln()

    # 6. FIX: Use pdf.output() without 'dest' and wrap in bytes()
    # In newer fpdf2, output() returns a bytearray/string based on usage
    pdf_bytes = bytes(pdf.output()) 

    response = make_response(pdf_bytes)
    response.headers["Content-Disposition"] = "attachment; filename=steelbeam_report.pdf"
    response.headers["Content-type"] = "application/pdf"
    return response

@app.route("/logout")
def logout():
    session.clear()  # Removes all data from the session
    return redirect(url_for("index"))

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)